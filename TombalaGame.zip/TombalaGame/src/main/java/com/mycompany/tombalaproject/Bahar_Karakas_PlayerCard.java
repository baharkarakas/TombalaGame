/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tombalaproject;

/**
 *
 * @author GIGABYTE
 */
public class Bahar_Karakas_PlayerCard {
    public Bahar_Karakas_PlayerCard() {
        
    }
}
